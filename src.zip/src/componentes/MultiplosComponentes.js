import React from "react";
import { Text } from 'react-native'

function CompOficial(){
    return <Text>Componente #Oficial</Text>
}
function Comp1(){
    return<Text>Componente 2</Text>
}
function Comp2(){
    return<Text>Componente 3</Text>
}
export {Comp1,Comp2}
export default CompOficial