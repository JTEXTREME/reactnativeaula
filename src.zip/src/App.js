import React from "react"
import{Text, View, StyleSheet} from 'react-native'
// import Primeiro from "./componentes/Primeiro"
// import Of,{Comp1,Comp2} from './componentes/MultiplosComponentes'
import MinMax from "./componentes/MinMax"
import Aleatorio from "./componentes/Aleatorio"

    // function App(){
    //    const jsx = <Text>Jailton Silva dos Anjos Junior</Text>
    //    return jsx
    // }

    // const App = function () {
    //     return <Text>Component 2</Text>
    // }

    // export default function() {
    //     return <Text>Component 3</Text>
    // }

    // export default () => {
    //     return <Text>Component 4</Text>
    // }

    export default () =>(
        <View style={styles.TelaIniciante}>
            {/* <Primeiro />
            <Text>1 + 2</Text>
            <Text>O valor da soma de 1 + 2 = {1 + 2}</Text>
            <Comp1 />
            <Comp2 />
            <Of/> */}
            {/* <MinMax min="3" max="20"/>
            <MinMax min="5" max="40"/>
            <MinMax min="7" max="55"/> */}
           <Aleatorio mino="2" maxo="10"/>
            <Aleatorio mino="5" maxo="40"/>
            <Aleatorio mino="7" maxo="55"/>
        </View>
    )
    

    // export default App

    const styles = StyleSheet.create({
        TelaIniciante: {
           flexGrow: 1 ,
           justifyContent: "center",
           alignItems: "center",
           padding: 20
        }
    })